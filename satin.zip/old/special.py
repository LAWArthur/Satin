from game import Skill, SkillFactory, Game
Game.make_game(3, 6)
