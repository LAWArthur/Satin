from game import Game, game
from defense import *
from attack import *

